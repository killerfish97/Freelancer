<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>

        <title></title>
           <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title></title>

    <!-- Icons font CSS-->
    <link href="colorlib-regform-1/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="colorlib-regform-1/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="colorlib-regform-1/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="colorlib-regform-1/vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="colorlib-regform-1/css/main.css" rel="stylesheet" media="all">
    <link rel="stylesheet" type="text/css" href="css/own.css">
    </head>
    <body>
        <?php
        include 'after_login_header.php';
        ?>  
        <?php
                 include 'dbh.php';
                $username= $_SESSION['name'];         
            $sql = "SELECT * FROM projects WHERE username='$username';";
             $result=mysqli_query($conn, $sql);
            if($result->num_rows>0){?>
                <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                     <h2 class="title">Projects</h2>
                    <?php
                while ($row = mysqli_fetch_array($result)) {  
        $proj_name_var=$row["proj_name"]; ?>
        <div class="chat-message">
            <label>Project Name: </label><?php echo "".$row["proj_name"];?><br>
             <label>Project Description: </label><?php echo "".$row["proj_desc"];?><br>
           <?php
            echo "<a href='edit_project.php?proj_name=$proj_name_var'>"
                    ."Edit</a>";
            echo "&nbsp;&nbsp;&nbsp;";
            echo "<a href='view_bid_owner.php?proj_name=$proj_name_var'>"
                    ."Biding Details</a>";
           ?>
             </div>
        <?php
                }?>           
        <form method="POST" >   
         <div class="p-t-20">
                              <button class="btn btn--radius btn--green" type="submit" formaction="ownerPage.php">Back</button>
                        </div>
            </form>
            </div>
        </div>
            </div>
             </div>
            
        <?php
                    
                } else {
                    ?>
        <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                            No Projects 
                               <form method="POST" >   
         <div class="p-t-20">
                              <button class="btn btn--radius btn--green" type="submit" formaction="ownerPage.php">Back</button>
                        </div>
            </form>
            </div>
        </div>
            </div>
             
            
        </div>
        <?php
                }        
              ?>
        ?>
        <?php
              
        include 'footer.php';
        ?>
    </body>
</html>
