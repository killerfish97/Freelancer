<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
       
    </head>
    <body>
        <?php
       include 'dbh.php';
       
            $uname = $_POST["username"];
            $pass = $_POST["pass"];
           $utype=$_POST["utype"];
            
            $sql = "INSERT INTO users(username,pwd,utype) VALUES('$uname','$pass','$utype');";
                        
              $inserted = mysqli_query($conn, $sql);
             if($inserted == 1)
            {
               header("Location:registered_successfull.php");
            }
            else
            {
                echo 'unsuccessfull';
            }
           
         
        ?>
    </body>
</html>
