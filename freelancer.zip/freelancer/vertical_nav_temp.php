<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <link rel="stylesheet" type="text/css" href="css/own.css">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
        <br>
        <br>
        <br>
        <br><br>
        
        <div class="asd">
        <ul class="abc">
            <li class="abcd"><a href="default.asp">Add Project</a></li>
  <li class="abcd"><a href="news.asp">View Projects</a></li>
  <li class="abcd"><a href="contact.asp">Owner Info</a></li>

</ul>
            </div>
     <br>
        <br>
        <br>
        <br><br>
    </body>
</html>
