class="input--style-1"<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
 <title></title>
  <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title></title>

    <!-- Icons font CSS-->
    <link href="colorlib-regform-1/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="colorlib-regform-1/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="colorlib-regform-1/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="colorlib-regform-1/vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="colorlib-regform-1/css/main.css" rel="stylesheet" media="all">
    <link rel="stylesheet" type="text/css" href="css/own.css">
    
    </head>
    <body>
        <?php
        include 'after_login_header.php';
        include 'dbh.php';
    $project_name=$_REQUEST['proj_name'];   
        $_SESSION['pname1']=$_REQUEST['proj_name'];   
          $sql1="select * from projects where proj_name='$project_name'";
          echo '$sql1';
         
         $result1=mysqli_query($conn, $sql1);
         $row= mysqli_fetch_array($result1);
          $_SESSION['pname1']= $row['proj_name']; 
       $username1=$_SESSION['name'];
        $bidDate=$row['bdate']; 
         ?>
                <br>
        <br>
        <br>
        <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Bidding Details</h2>
                    <h2><?php echo $project_name;?></h2>
                    <div class="chat-message">
                           <?php
                             $sql1="select * from proj_biding where proj_name='$project_name' and username='$username1';";                                
 $result1=mysqli_query($conn, $sql1);
                                if($result1->num_rows>0){
                            while ($row4 = mysqli_fetch_array($result1)) {           
                           ?>                        
                            <div class="chat-details">
                                                              
                        <label><b>Bidder Name :</b></label> <?php echo $row4['worker_name'];?>
                        <br>                                               
                        <label><b>Days :</b></label><?php echo $row4['days'];?> Days 
                          <br>  
                         <label><b>Amount :</b></label>Rs:<?php echo $row4['amount'];?>
                           <br>
                          <?php
                          $wr_n= $row4['worker_name'];
                          echo "<a href='approve.php?pname=$project_name&ownername=$username1&workername=$wr_n&bdate=$bidDate'>"
                    ."Approve</a>";
                          ?>
                            </div>
                        <?php
                }
                                } else {?>
                                    <div class="chat-details">
                        No Biding
                        </div>
                                <?php
                                         }
                        ?>
                    </div>

                    <form>
                         <div class="p-t-20">
                              <button class="btn btn--radius btn--green" type="submit" formaction="view_projects.php">Back</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
        <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>    
     <?php
        include 'footer.php';
        ?>
    </body>
</html>
