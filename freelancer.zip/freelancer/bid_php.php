<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
       <?php
       include 'dbh.php';
       session_start();
                      
                          $worker_name=$_SESSION['name'];
                          $days_var=$_REQUEST["date"];
                          $amount_var=$_REQUEST["amount"];
                          $project_name1=$_SESSION['pname1'];
                          $user_var=$_SESSION['username_of_project'];
                          $sql1="SELECT * FROM projects WHERE username='$user_var' AND proj_name='$project_name1 ';";
                           $result1=mysqli_query($conn, $sql1);
                           $row1 = mysqli_fetch_array($result1);
                          $bdate=$row1["bdate"]; 
                          
                          $amount_max=$row1["budget"];
                          if($amount_var<$amount_max){
                          $sql2="SELECT * FROM worker_freeze WHERE worker_name='$worker_name' and '$bdate' BETWEEN from_date AND to_date;";
                           $result2=mysqli_query($conn, $sql2);

                            if($result2->num_rows>0 ){
                                 header("Location:your_already_in_project.php");
                            }else{
                                  $sql = "INSERT INTO proj_biding(username,worker_name,proj_name,days,amount) VALUES('$user_var','$worker_name','$project_name1',$days_var,$amount_var);";
                        
                            $inserted5 = mysqli_query($conn, $sql);

                          if($inserted5 == 1)
                          {
                              header("Location:bid_successfull.php");
                          }
                          else
                          {
                               header("Location:already_bid.php");
                          }
                                          }
                          
                          } else {
                              header("Location:max_amount.php");
                       
                          
                            }
                               
                      
                     ?>
    </body>
</html>
