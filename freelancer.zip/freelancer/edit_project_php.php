<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
         if (isset($_POST["submit1"])) {
        session_start();
           include 'dbh.php';
           $proj_desc = $_POST["pdesc"];
           $budget=$_POST["budget"];
           $bdate=$_POST["bdate"];
           $username= $_SESSION['name'];
           $project_name_var1=$_SESSION['project_name'];
           echo $project_name_var1;
           $sql3 = "UPDATE projects SET proj_desc='$proj_desc', budget=$budget,bdate='$bdate' WHERE proj_name='$project_name_var1';";      
              $updated = mysqli_query($conn, $sql3);
             if($updated == 1)
            {
               header("Location:updated_successfully.php");
            }
            else
            {
                header("Location:error_page.php");
            }
         }
        ?>
    </body>
</html>
