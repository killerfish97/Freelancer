class="input--style-1"<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
 <title></title>
  <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title></title>

    <!-- Icons font CSS-->
    <link href="colorlib-regform-1/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="colorlib-regform-1/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="colorlib-regform-1/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="colorlib-regform-1/vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="colorlib-regform-1/css/main.css" rel="stylesheet" media="all">
     <link rel="stylesheet" type="text/css" href="css/own.css">
    <script type="text/javascript">
   function check_category(){
    var cate=document.getElementById("cate").value;
   if(cate=="select"){
         alert("Select Project Type");
         return false;
     }
    
 }
    </script>
    </head>
    <body>
        <?php
        include 'after_login_header.php';
        ?>       
        <br>
        <br>
        <br>
        <div class="page-wrapper bg-blue p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Search Project</h2>
                    <form action="search_page.php" onsubmit="return check_category()" method="POST" >                         
                              <label>Select Category</label>
                            <select name="cate"id="cate">
                                    <option value="select">Select</option>
                                     <option value="graphic_design">Graphic Design</option>
                                      <option value="web_design">Web Design</option>
                                       <option value="mobile_apps">Mobile Apps</option>                                      
                                </select>         
                              
                             <button class="btn btn--radius btn--green" type="submit" name="submit1">Search</button>
                        
                    </form>
                    <?php
                      if(isset($_POST["submit1"]))
                                {
                          date_default_timezone_set("Asia/Kolkata");
                            $today = date("Y-m-d");
                          include 'dbh.php';  
                          $proj_cate= $_POST["cate"];
                                    $sq2l="SELECT * FROM projects WHERE proj_cate='$proj_cate' AND '$today'<bdate;";
                                    
                                    $result=mysqli_query($conn, $sq2l);
                                     if($result->num_rows>0 ){?>
                    <?php
                while ($row = mysqli_fetch_array($result)) {  
        $proj_name_var=$row["proj_name"]; ?>
        <div class="chat-message">
            <label>Project Name: </label><?php echo "".$row["proj_name"];?><br>
             <label>Project Description: </label><?php echo "".$row["proj_desc"];?><br>
           <?php
            echo "<a href='open_project.php?proj_name=$proj_name_var'>"
                    ."Open</a>";
           ?>
             </div>
                     <?php
                }
                                } else {?>
                    <div class="chat-message">
                    <h5>No Projects</h5>
                                </div>
                                  <?php
                                   }
                                }
                                ?>
                    </div>
                    <form>
                         <div class="p-t-20">
                             <button class="btn btn--radius btn--green" type="submit" formaction="workerPage.php">Back</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>    
        <?php
        include 'footer.php';
        ?>
    </body>
</html>
