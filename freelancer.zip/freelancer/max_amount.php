
        <?php
      // include 'after_login_header.php';
      session_start();
       $project_name1=$_SESSION['pname1'];
 print "<script type='text/javascript'>alert('Exceeded Bid Amount');window.location='open_project.php?proj_name=$project_name1';</script>";
        ?>

